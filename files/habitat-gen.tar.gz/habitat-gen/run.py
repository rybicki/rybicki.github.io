#!/usr/bin/python

import sys
import math

import matplotlib.pyplot as pp

from habitat import HabitatGenerator

# Parse command line arguments
if len(sys.argv) < 4:
	print "Usage: %s [output file] [size] [weight factor] [OPTIONS ... ]" % (sys.argv[0],)
	print " --shift \t use randomised origo shifting"
	sys.exit(1)

out_fname = sys.argv[1]
dim = int(sys.argv[2])

assert 2**math.log(dim,2) == dim, "Size should be a power of two."

omega = float(sys.argv[3])
shifting = False

if '--shift' in sys.argv:
	shifting = True

# Print information 
print "Generating a %ix%i habitat matrix to file '%s'." % (dim,dim,out_fname,)
print "Weight factor: %.2f. Randomised shifting: %s." % (omega, "on" if shifting else "off")

# Run generator
hgen = HabitatGenerator(dim,dim,omega,shifting)
habitat = hgen.generate()

print habitat

# Plot the habitat with matplotlib and write it to a file
print "Writing to '%s'" % (out_fname,)

pp.imshow(habitat, vmin=0, vmax=1.0, interpolation='none')
pp.axis('off')
pp.savefig(out_fname)

print "Done."